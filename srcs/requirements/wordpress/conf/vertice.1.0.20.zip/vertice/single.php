<?php get_header(); ?>
<?php vertice_theme()->get( 'single' )->render(); ?>
<?php
get_footer();
