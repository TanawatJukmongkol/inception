<div class="wp-block wp-block-kubio-section  position-relative wp-block-kubio-section__outer vertice-404__k__TvUIu7nWc-outer vertice-local-638-outer d-flex h-section-global-spacing align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/section">
	<div class="position-relative wp-block-kubio-section__inner vertice-404__k__TvUIu7nWc-inner vertice-local-638-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container vertice-404__k__-raj3DSmnW-container vertice-local-639-container gutters-row-lg-2 gutters-row-v-lg-0 gutters-row-md-2 gutters-row-v-md-2 gutters-row-2 gutters-row-v-2" data-kubio="kubio/row">
			<div class="position-relative wp-block-kubio-row__inner vertice-404__k__-raj3DSmnW-inner vertice-local-639-inner h-row align-items-lg-start align-items-md-start align-items-start justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-2 gutters-col-v-lg-0 gutters-col-md-2 gutters-col-v-md-2 gutters-col-2 gutters-col-v-2">
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-404__k__TYq4YGB3vx-container vertice-local-640-container d-flex h-col-lg-auto h-col-md-auto h-col-auto align-self-lg-start align-self-md-start align-self-start" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner vertice-404__k__TYq4YGB3vx-inner vertice-local-640-inner d-flex h-flex-basis h-px-lg-2 v-inner-lg-2 h-px-md-2 v-inner-md-2 h-px-2 v-inner-2">
						<div class="position-relative wp-block-kubio-column__align vertice-404__k__TYq4YGB3vx-align vertice-local-640-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
							<h3 class="wp-block wp-block-kubio-heading  position-relative wp-block-kubio-heading__text vertice-404__k__CryHflZk8-text vertice-local-641-text" data-kubio="kubio/heading">
								<?php esc_html_e('Page not found', 'vertice'); ?>
							</h3>
							<div class="position-relative wp-block-kubio-home-button__ vertice-404__k__XE8iPl7Auw- vertice-local-642-">
								<span class="wp-block wp-block-kubio-home-button  position-relative wp-block-kubio-home-button__outer vertice-404__k__XE8iPl7Auw-outer vertice-local-642-outer kubio-button-container" data-kubio="kubio/home-button">
									<a class="position-relative wp-block-kubio-home-button__link vertice-404__k__XE8iPl7Auw-link vertice-local-642-link h-w-100 h-global-transition" href="<?php echo esc_url(home_url()); ?>">
										<span class="h-svg-icon wp-block-kubio-home-button__icon vertice-404__k__XE8iPl7Auw-icon vertice-local-642-icon" name="icons8-line-awesome/home">
											<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="home" viewBox="0 0 512 545.5">
												<path d="M256 73.5l11.5 11 208 208-23 23L432 295v185H288V320h-64v160H80V295l-20.5 20.5-23-23 208-208zm0 45.5L112 263v185h80V288h128v160h80V263z"/></svg>
											</span>
											<span class="position-relative wp-block-kubio-home-button__text vertice-404__k__XE8iPl7Auw-text vertice-local-642-text kubio-inherit-typography">
												<?php esc_html_e('Go to Homepage!', 'vertice'); ?>
											</span>
										</a>
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
