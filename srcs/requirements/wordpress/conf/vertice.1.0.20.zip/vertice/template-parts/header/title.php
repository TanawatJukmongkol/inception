<h1 class="wp-block wp-block-kubio-page-title  position-relative wp-block-kubio-page-title__container vertice-header__k__SzZXH7PdCL-container vertice-local-643-container" data-kubio="kubio/page-title">
	<?php vertice_print_page_title(); ?>
</h1>
