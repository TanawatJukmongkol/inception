<span class="wp-block wp-block-kubio-button  position-relative wp-block-kubio-button__outer vertice-front-header__k__Dud6AOZG0Hc-outer vertice-local-134-outer kubio-button-container" data-kubio="kubio/button">
	<a class="position-relative wp-block-kubio-button__link vertice-front-header__k__Dud6AOZG0Hc-link vertice-local-134-link h-w-100 h-global-transition" href="<?php echo esc_url(\ColibriWP\Theme\View::getData('url')); ?>">
		<span class="position-relative wp-block-kubio-button__text vertice-front-header__k__Dud6AOZG0Hc-text vertice-local-134-text kubio-inherit-typography">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('label')); ?>
		</span>
	</a>
</span>
