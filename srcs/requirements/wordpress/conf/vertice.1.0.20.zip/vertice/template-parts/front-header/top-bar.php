<div class="wp-block wp-block-kubio-navigation-top-bar  kubio-hide-on-mobile position-relative wp-block-kubio-navigation-top-bar__outer vertice-front-header__k__KbTDfF53jMP-outer vertice-local-91-outer d-flex align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/navigation-top-bar">
	<div class="background-wrapper">
		<div class="background-layer background-layer-media-container-lg"></div>
		<div class="background-layer background-layer-media-container-md"></div>
		<div class="background-layer background-layer-media-container"></div>
	</div>
	<div class="position-relative wp-block-kubio-navigation-top-bar__inner vertice-front-header__k__KbTDfF53jMP-inner vertice-local-91-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container vertice-front-header__k__HKyGNDS4CzE-container vertice-local-92-container gutters-row-lg-0 gutters-row-v-lg-0 gutters-row-md-0 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/row">
			<div class="background-wrapper">
				<div class="background-layer background-layer-media-container-lg"></div>
				<div class="background-layer background-layer-media-container-md"></div>
				<div class="background-layer background-layer-media-container"></div>
			</div>
			<div class="position-relative wp-block-kubio-row__inner vertice-front-header__k__HKyGNDS4CzE-inner vertice-local-92-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-0 gutters-col-md-0 gutters-col-v-md-0 gutters-col-0 gutters-col-v-0">
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-front-header__k__-8K_1QtHVcl-container vertice-local-93-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner vertice-front-header__k__-8K_1QtHVcl-inner vertice-local-93-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align vertice-front-header__k__-8K_1QtHVcl-align vertice-local-93-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php vertice_theme()->get('top-bar-list-icons')->render(); ?>
						</div>
					</div>
				</div>
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-front-header__k__Wd8PGL3fFpa-container vertice-local-101-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner vertice-front-header__k__Wd8PGL3fFpa-inner vertice-local-101-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align vertice-front-header__k__Wd8PGL3fFpa-align vertice-local-101-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php vertice_theme()->get('top-bar-social-icons')->render(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
