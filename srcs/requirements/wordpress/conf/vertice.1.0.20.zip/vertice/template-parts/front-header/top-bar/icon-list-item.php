<li class="wp-block wp-block-kubio-iconlistitem  position-relative wp-block-kubio-iconlistitem__item vertice-front-header__k__6aAmGjJwxWl-item vertice-local-99-item" data-kubio="kubio/iconlistitem">
	<div class="position-relative wp-block-kubio-iconlistitem__text-wrapper vertice-front-header__k__6aAmGjJwxWl-text-wrapper vertice-local-99-text-wrapper">
		<span class="h-svg-icon wp-block-kubio-iconlistitem__icon vertice-front-header__k__6aAmGjJwxWl-icon vertice-local-99-icon" name="font-awesome/envelope">
			<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
		</span>
		<span class="position-relative wp-block-kubio-iconlistitem__text vertice-front-header__k__6aAmGjJwxWl-text vertice-local-99-text">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
		</span>
	</div>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper vertice-front-header__k__6aAmGjJwxWl-divider-wrapper vertice-local-99-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper vertice-front-header__k__6aAmGjJwxWl-divider-wrapper vertice-local-99-divider-wrapper"></div>
</li>
